# Experiment 3: CPU Scheduling Algorithms

## 3(a) First Come First Serve (FCFS) Scheduling

```c
#include <stdio.h>

int main()
{
    int n, i;
    int pid[20], st[20];
    int wt[20], tat[20];
    int total_wt = 0, total_tat = 0;
    float avg_wt, avg_tat;

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    printf("\nEnter Process ID and Service Time:\n");
    for(i = 0; i < n; i++)
    {
        printf("Process %d ID: ", i + 1);
        scanf("%d", &pid[i]);

        printf("Service Time: ");
        scanf("%d", &st[i]);
    }

    wt[0] = 0;
    tat[0] = st[0];

    total_wt += wt[0];
    total_tat += tat[0];

    for(i = 1; i < n; i++)
    {
        wt[i] = tat[i - 1];
        tat[i] = wt[i] + st[i];

        total_wt += wt[i];
        total_tat += tat[i];
    }

    avg_wt = (float)total_wt / n;
    avg_tat = (float)total_tat / n;

    printf("\n-------------------------------------------------------------\n");
    printf("PID\tService Time\tWaiting Time\tTurnaround Time\n");
    printf("-------------------------------------------------------------\n");

    for(i = 0; i < n; i++)
    {
        printf("%d\t%d\t\t%d\t\t%d\n", pid[i], st[i], wt[i], tat[i]);
    }

    printf("-------------------------------------------------------------\n");
    printf("Average Waiting Time    = %.2f\n", avg_wt);
    printf("Average Turnaround Time = %.2f\n", avg_tat);

    return 0;
}
```

## 3(b) Shortest Job First (SJF) Scheduling

```c
#include <stdio.h>

int main()
{
    int n, i, j;
    int pid[20], st[20];
    int wt[20], tat[20];
    int temp;
    int total_wt = 0, total_tat = 0;
    float avg_wt, avg_tat;

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    printf("\nEnter Process ID and Service Time:\n");
    for(i = 0; i < n; i++)
    {
        printf("Process %d ID: ", i + 1);
        scanf("%d", &pid[i]);

        printf("Service Time: ");
        scanf("%d", &st[i]);
    }

    /* Sort processes according to Service Time */
    for(i = 0; i < n - 1; i++)
    {
        for(j = i + 1; j < n; j++)
        {
            if(st[i] > st[j])
            {
                temp = st[i];
                st[i] = st[j];
                st[j] = temp;

                temp = pid[i];
                pid[i] = pid[j];
                pid[j] = temp;
            }
        }
    }

    wt[0] = 0;
    tat[0] = st[0];

    total_wt = wt[0];
    total_tat = tat[0];

    for(i = 1; i < n; i++)
    {
        wt[i] = tat[i - 1];
        tat[i] = wt[i] + st[i];

        total_wt += wt[i];
        total_tat += tat[i];
    }

    avg_wt = (float)total_wt / n;
    avg_tat = (float)total_tat / n;

    printf("\n------------------------------------------------------------\n");
    printf("PID\tService Time\tWaiting Time\tTurnaround Time\n");
    printf("------------------------------------------------------------\n");

    for(i = 0; i < n; i++)
    {
        printf("%d\t%d\t\t%d\t\t%d\n",
               pid[i], st[i], wt[i], tat[i]);
    }

    printf("------------------------------------------------------------\n");
    printf("Average Waiting Time    = %.2f\n", avg_wt);
    printf("Average Turnaround Time = %.2f\n", avg_tat);

    return 0;
}
```

## 3(c) Round Robin Scheduling

```c
#include <stdio.h>

int main()
{
    int i, n, tq;
    int pid[20], bt[20], rt[20];
    int wt[20], tat[20];
    int time = 0, remain, flag = 0;
    float avg_wt = 0, avg_tat = 0;

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    remain = n;

    printf("\nEnter Process ID and Burst Time:\n");
    for(i = 0; i < n; i++)
    {
        printf("Process %d ID: ", i + 1);
        scanf("%d", &pid[i]);

        printf("Burst Time: ");
        scanf("%d", &bt[i]);

        rt[i] = bt[i];
    }

    printf("\nEnter Time Quantum: ");
    scanf("%d", &tq);

    printf("\n-------------------------------------------------------------\n");
    printf("PID\tBurst Time\tWaiting Time\tTurnaround Time\n");
    printf("-------------------------------------------------------------\n");

    for(i = 0; remain != 0; )
    {
        if(rt[i] <= tq && rt[i] > 0)
        {
            time += rt[i];
            rt[i] = 0;
            flag = 1;
        }
        else if(rt[i] > 0)
        {
            rt[i] -= tq;
            time += tq;
        }

        if(flag == 1 && rt[i] == 0)
        {
            remain--;

            tat[i] = time;
            wt[i] = tat[i] - bt[i];

            avg_wt += wt[i];
            avg_tat += tat[i];

            printf("%d\t%d\t\t%d\t\t%d\n",
                   pid[i], bt[i], wt[i], tat[i]);

            flag = 0;
        }

        if(i == n - 1)
            i = 0;
        else
            i++;
    }

    printf("-------------------------------------------------------------\n");
    printf("Average Waiting Time = %.2f\n", avg_wt / n);
    printf("Average Turnaround Time = %.2f\n", avg_tat / n);

    return 0;
}
```

## 3(d) Priority Scheduling

```c
#include <stdio.h>

struct process
{
    int pid;
    int bt;
    int pri;
    int wt;
    int tat;
};

int main()
{
    struct process p[20], temp;
    int n, i, j;
    int total_wt = 0, total_tat = 0;
    float avg_wt, avg_tat;

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    printf("\nEnter Process ID, Burst Time and Priority:\n");

    for(i = 0; i < n; i++)
    {
        printf("\nProcess %d\n", i + 1);

        printf("Process ID : ");
        scanf("%d", &p[i].pid);

        printf("Burst Time : ");
        scanf("%d", &p[i].bt);

        printf("Priority (Lower number = Higher Priority): ");
        scanf("%d", &p[i].pri);
    }

    /* Sort according to Priority */
    for(i = 0; i < n - 1; i++)
    {
        for(j = i + 1; j < n; j++)
        {
            if(p[i].pri > p[j].pri)
            {
                temp = p[i];
                p[i] = p[j];
                p[j] = temp;
            }
        }
    }

    p[0].wt = 0;
    p[0].tat = p[0].bt;

    total_wt = p[0].wt;
    total_tat = p[0].tat;

    for(i = 1; i < n; i++)
    {
        p[i].wt = p[i-1].tat;
        p[i].tat = p[i].wt + p[i].bt;

        total_wt += p[i].wt;
        total_tat += p[i].tat;
    }

    avg_wt = (float)total_wt / n;
    avg_tat = (float)total_tat / n;

    printf("\n---------------------------------------------------------------\n");
    printf("PID\tBT\tPriority\tWT\tTAT\n");
    printf("---------------------------------------------------------------\n");

    for(i = 0; i < n; i++)
    {
        printf("%d\t%d\t%d\t\t%d\t%d\n",
               p[i].pid,
               p[i].bt,
               p[i].pri,
               p[i].wt,
               p[i].tat);
    }

    printf("---------------------------------------------------------------\n");
    printf("Average Waiting Time = %.2f\n", avg_wt);
    printf("Average Turnaround Time = %.2f\n", avg_tat);

    return 0;
}
```
